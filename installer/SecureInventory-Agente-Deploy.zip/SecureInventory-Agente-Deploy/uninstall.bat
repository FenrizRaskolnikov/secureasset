@echo off
:: Cambiar al directorio actual del script
cd /d "%~dp0"

echo [!] Desinstalando Agente de Seguridad SecureInventory...

:: 1. Forzar el cierre del proceso si está activo (silenciando errores si no corre)
taskkill /f /im agente.exe 2>nul

:: 2. Eliminar la tarea programada del sistema
schtasks /delete /tn "SecureInventoryAgent" /f 2>nul

:: 3. Borrar por completo la carpeta de instalación y sus archivos (.env y .exe)
rmdir /s /q "C:\ProgramData\SecureInventory" 2>nul

echo.
echo [¡EXITO!] El agente y todos sus registros han sido eliminados correctamente del equipo.
pause