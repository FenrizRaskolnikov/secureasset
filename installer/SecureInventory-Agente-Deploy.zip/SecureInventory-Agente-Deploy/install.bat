@echo off
cd /d "%~dp0"

echo [+] Instalando Agente de Seguridad SecureInventory...

:: Crear carpeta de destino en ProgramData
mkdir "C:\ProgramData\SecureInventory" 2>nul

:: Copiar el ejecutable y el .env
copy "agente.exe" "C:\ProgramData\SecureInventory\"
copy ".env" "C:\ProgramData\SecureInventory\"

:: Crear la Tarea Programada para que corra al encender el sistema (ONSTART) con altos privilegios
schtasks /create /tn "SecureInventoryAgent" /tr "C:\ProgramData\SecureInventory\agente.exe" /sc ONSTART /rl HIGHEST /f

echo [+] Iniciando el agente de inmediato...
start "" "C:\ProgramData\SecureInventory\agente.exe"

echo [¡EXITO!] Agente instalado, programado y ejecutado con éxito.
pause